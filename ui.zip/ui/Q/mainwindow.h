#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
/*
private slots://加的
    void on_checkBox_clicked(bool checked);
    void setTextFontColor();
*/
private slots:
    void Paint();
    void Delete();
    void Fl();
private:
    Ui::MainWindow *ui;
    QImage image;//加的

protected:
    void paintEvent(QPaintEvent *);
 //   void Paint();
};
#endif // MAINWINDOW_H
