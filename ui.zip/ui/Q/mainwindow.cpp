#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include<QtGui>
#include <vector>
#include <QFileDialog>
#include <qfile.h>
#include <qtextstream.h>
#include <core.h>

void P(QImage* image);

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(Paint()));
    connect(ui->pushButton_2,SIGNAL(clicked()),this,SLOT(Delete()));
    connect(ui->pushButton_3,SIGNAL(clicked()),this,SLOT(Fl()));

    image = QImage(600,600,QImage::Format_RGB32);  //画布的初始化大小设为600*500，使用32位颜色
    QColor backColor = qRgb(255,255,255);    //画布初始化背景色使用白色
    image.fill(backColor);//对画布进行填充
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
        QPainter painter(this);
        painter.drawImage(0,0,image);
}

typedef struct Line_1
{
    char type;
    int x0;
    int y0;
    int x1;
    int y1;
}line_1;

typedef struct Circle_1
{
    int x;
    int y;
    int r;
}circle_1;

int get_x(int x)
{
    return 10*x+300;
}

int get_y(int y)
{
    return 300 - y*10;
}

std::vector<line_1> lines;
std::vector<circle_1> circles;

void MainWindow::Fl()
{
    QString fileName;
    fileName = QFileDialog::getOpenFileName(this,tr("文件"), "", tr("text(*.txt)"));
    QFile f(fileName);
    f.open(QIODevice::ReadOnly);
    QTextStream t(&f);
    while (!t.atEnd())
    {
        QString s0 = t.readLine();
        std::string s = s0.toStdString();
        //L 0 0 1 1

        int number = -1;
        QStringList temp = s0.split(" ");
        int ns[5];

        QList<QString>::Iterator it = temp.begin();

        for (;it != temp.end();it++,number++)
        {
            if (number == -1)
            {
                continue;
            }
            ns[number] = it->toInt();
        }

        if (s[0] == 'C')
        {
            circle_1 c;
            c.x = ns[0];
            c.y = ns[1];
            c.r = ns[2];
            circles.push_back(c);
        }
        else {
            line_1 l;
            if (s[0] == 'L')    l.type = 'L';
            else if (s[0] == 'R')   l.type = 'R'; //射线
            else if (s[0] == 'S')   l.type = 'S'; //线段
            l.x0 = ns[0];
            l.y0 = ns[1];
            l.x1 = ns[2];
            l.y1 = ns[3];
            lines.push_back(l);
        }
    }
    f.close();

    P(&image);
}

void MainWindow::Delete()
{
    QString s0 = ui->textEdit->toPlainText();

    std::string s = s0.toStdString();
    //L 0 0 1 1

    int number = -1;
    QStringList temp = s0.split(" ");
    int ns[5];

    QList<QString>::Iterator it = temp.begin();

    for (;it != temp.end();it++,number++)
    {
        if (number == -1)
        {
            continue;
        }
        ns[number] = it->toInt();
    }

    if (s[0] == 'C')
    {
        circle_1 c;
        c.x = ns[0];
        c.y = ns[1];
        c.r = ns[2];
        int length = -1;
        for (int i = 0;i < circles.size();i++)
        {
            if (circles[i].x == c.x && circles[i].y == c.y && circles[i].r == c.r)
            {
                length = i;
                break;
            }
        }
        if (length != -1)
        {
            circles.erase(circles.begin()+length);
        }
    }
    else {
        line_1 l;
        if (s[0] == 'L')    l.type = 'L';
        else if (s[0] == 'R')   l.type = 'R'; //射线
        else if (s[0] == 'S')   l.type = 'S'; //线段
        l.x0 = ns[0];
        l.y0 = ns[1];
        l.x1 = ns[2];
        l.y1 = ns[3];
        int length = -1;
        for (int i = 0;i < lines.size();i++)
        {
            if (lines[i].x0 == l.x0 &&lines[i].y0 == l.y0 && lines[i].x1 == l.x1 && lines[i].y1 == l.y1)
            {
                length = i;
                break;
            }
        }
        if (length != -1)
        {
            lines.erase(lines.begin()+length);
        }
    }

    P(&image);
}

void MainWindow::Paint()
{
    QString s0 = ui->textEdit->toPlainText();

    std::string s = s0.toStdString();
    //L 0 0 1 1

    int number = -1;
    QStringList temp = s0.split(" ");
    int ns[5];

    QList<QString>::Iterator it = temp.begin();

    for (;it != temp.end();it++,number++)
    {
        if (number == -1)
        {
            continue;
        }
        ns[number] = it->toInt();
    }

    if (s[0] == 'C')
    {
        circle_1 c;
        c.x = ns[0];
        c.y = ns[1];
        c.r = ns[2];
        circles.push_back(c);
    }
    else {
        line_1 l;
        if (s[0] == 'L')    l.type = 'L';
        else if (s[0] == 'R')   l.type = 'R'; //射线
        else if (s[0] == 'S')   l.type = 'S'; //线段
        l.x0 = ns[0];
        l.y0 = ns[1];
        l.x1 = ns[2];
        l.y1 = ns[3];
        lines.push_back(l);
    }
    P(&image);
}

void P(QImage* image)
{
    QColor backColor = qRgb(255, 255, 255);
    image->fill(backColor);
    QPainter painter(image);

    painter.setRenderHint(QPainter::Antialiasing, true);//设置反锯齿模式，好看一点
    int pointx = 300, pointy = 300;//确定坐标轴起点坐标
    int width = 300, height = 300;//确定坐标轴宽度跟高度 上文定义画布为600X600，宽高依此而定。

    painter.drawLine(pointx + 10, pointy, pointx + 10, pointy - 5);//刻度线
    painter.drawText(pointx + 10, pointy + 10, "1");

    painter.drawLine(pointx - width, pointy, width + pointx, pointy);//坐标轴x宽度为width
    painter.drawLine(pointx, pointy - height, pointx, pointy + height);//坐标轴y高度为height


    //10*x-300, 300 - y*10;
    for (int i = 0; i < lines.size(); i++)
    {
        if (lines[i].type == 'R')
        {
            painter.drawPoint(get_x(lines[i].x0), get_y(lines[i].y0));
        }
        else if (lines[i].type == 'S')
        {
        painter.drawPoint(get_x(lines[i].x0), get_y(lines[i].y0));
            painter.drawPoint(get_x(lines[i].x1), get_y(lines[i].y1));
        }
        painter.drawLine(get_x(lines[i].x0), get_y(lines[i].y0), get_x(lines[i].x1), get_y(lines[i].y1));
    }

    for (int i = 0; i < circles.size(); i++)
    {
        painter.drawEllipse(get_x(circles[i].x) - 10 * circles[i].r, get_y(circles[i].y) - 10 * circles[i].r, 20 * circles[i].r, 20 * circles[i].r);
    }

    Solve sv;


    set<pair<double, double>, cmp> intersections;
    for (int i = 0; i < lines.size(); i++)
    {
        for (int j = i+1; j < lines.size(); j++)
        {
            Line l1(lines[i].x0, lines[i].y0, lines[i].x1, lines[i].y1, lines[i].type);
            Line l2(lines[j].x0, lines[j].y0, lines[j].x1, lines[j].y1, lines[j].type);

            if (l1.type == 'L' && l1.type == 'L')  sv.LLintersect(&intersections, l1, l2);
            else if (l1.type == 'R' && l1.type == 'R') sv.RRintersect(&intersections, l1, l1);
            else if (l1.type == 'S' && l1.type == 'S') sv.SSintersect(&intersections, l1, l1);
            else if (l1.type == 'R' && l1.type == 'L') sv.LRintersect(&intersections, l1, l1);
            else if (l1.type == 'L' && l1.type == 'R') sv.LRintersect(&intersections, l1, l1);
            else if (l1.type == 'L' && l1.type == 'S') sv.LSintersect(&intersections, l1, l1);
            else if (l1.type == 'S' && l1.type == 'L') sv.LSintersect(&intersections, l1, l1);
            else if (l1.type == 'S' && l1.type == 'R') sv.SRintersect(&intersections, l1, l1);
            else if (l1.type == 'R' && l1.type == 'S') sv.SRintersect(&intersections, l1, l1);
        }
    }

    for (int i = 0; i < lines.size(); i++)
    {
        for (int j = 0; j < circles.size(); j++)
        {
            Line l(lines[i].x0, lines[i].y0, lines[i].x1, lines[i].y1, lines[i].type);
            Circle c(circles[j].x, circles[j].y, circles[j].r);
            if (lines[i].type == 'L') sv.LCintersect(&intersections, l, c);
            else if (lines[i].type == 'R') sv.RCintersect(&intersections, l, c);
            else if (lines[i].type == 'S') sv.SCintersect(&intersections, l, c);
        }
    }

    for (int i = 0; i < circles.size(); i++)

    {
        for (int j = i+1; j < circles.size(); j++)
        {
            Circle c1(circles[i].x, circles[i].y, circles[i].r);
            Circle c2(circles[j].x, circles[j].y, circles[j].r);
            sv.CCintersect(&intersections, c1, c2);
        }


    }

    for (auto it : intersections)
    {
        painter.drawPoint(it.first, it.second);
        QString s = "(" + QString::number(it.first) + "," + QString::number(it.second) + ")";
        painter.drawText(get_x(int(it.first)) + 20, get_y(int(it.second)), s);
    }
}


